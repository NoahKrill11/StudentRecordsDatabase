﻿using System;
using System.Web.UI;
using System.Text;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;


namespace WebApplication2
{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void makeTeacher(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                String TeachersName = TextBox1.Text;
                String sb = ("INSERT into Teacher (TeacherName) VALUES (@TeacherName)");
                connection.Open();
                using (SqlCommand command = new SqlCommand(sb, connection))
                {

                    command.Parameters.AddWithValue("@TeacherName", TeachersName);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }

        protected void enrollTeacher(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                int num, TeacherID;
                String TeachersName =(TextBox2.Text);
                int CourseID = Convert.ToInt32(TextBox3.Text);
                String sb = "SELECT COUNT(CourseNumber) FROM CoursesTaught WHERE CourseNumber = @CourseID";
                connection.Open();
                using (SqlCommand command = new SqlCommand(sb, connection))
                {
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    num = (int) command.ExecuteScalar();
                }
                if(num==1)
                {
                    String sb2 = "SELECT TeacherID FROM Teacher WHERE TeacherName = @TeacherName";
                    using (SqlCommand command = new SqlCommand(sb2, connection))
                    {
                        command.Parameters.AddWithValue("@TeacherName", TeachersName);
                        TeacherID = (int)command.ExecuteScalar();
                    }
                    String sb3 = "INSERT into teaches (TeacherID, CourseNumber) VALUES (@TeacherID, @CourseID) ";
                    using (SqlCommand command = new SqlCommand(sb3, connection))
                    {
                        command.Parameters.AddWithValue("@TeacherID", TeacherID);
                        command.Parameters.AddWithValue("@CourseID", CourseID);
                        command.ExecuteNonQuery();


                    }
                }
                connection.Close();
            }
        }
        protected void addClass(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                String Courses = TextBox4.Text;
                String bs = "INSERT into CoursesTaught (Courses) VALUES (@Courses)";
                connection.Open();
                using (SqlCommand command = new SqlCommand(bs, connection))
                {
                    command.Parameters.AddWithValue("@Courses", Courses);
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }

            }

    }
}