﻿using System;
using System.Web.UI;
using System.Text;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class Default2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void printClass(int studentID)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT IDandClassID.CourseID, Courses.NameOfCourse, Courses.TeacherName FROM IDandClassID, Courses WHERE StudentID = " + studentID + " AND IDandClassID.CourseID = Courses.CourseNumber");
                String sql = sb.ToString();
                SqlCommand cmd = new SqlCommand(sql, connection);
                connection.Open();
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    GridView2.DataSource = dt;
                    GridView2.DataBind();
                }
                connection.Close();
            }
        }
        protected void verifyStudent(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            int studentid = Convert.ToInt32(TxtSearch.Text);
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                int ID = Convert.ToInt32(TxtSearch.Text);
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT Person.FirstName, Person.LastName, Student.StudentID, Student.Email FROM Student, Person WHERE StudentID = " + studentid + " AND Person.PersonID = Student.PersonID");
                String sql = sb.ToString();
                SqlCommand cmd = new SqlCommand(sql, connection);
                connection.Open();
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                connection.Close();
                printClass(studentid);
            }

        }

    }
        }