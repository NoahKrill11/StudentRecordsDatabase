﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Data;

namespace WebApplication2
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void Button_login_Click(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                String sb;
                try
                {
                    int Teacher = Convert.ToInt32(TeacherID.Text);
                    sb = "SELECT count(TeacherID) FROM Teacher Where TeacherID = " + Teacher;
                    connection.Open();
                    SqlCommand cmd = new SqlCommand(sb, connection);
                    String output = cmd.ExecuteScalar().ToString();
                    if (output == "1")
                    {
                        Response.Redirect("~/Default.aspx");
                    }
                    else
                    {

                    }
                    connection.Close();
                }
                catch (Exception)
                {

                }
            }
       
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TeacherPassword_TextChanged(object sender, EventArgs e)
        {

        }

        protected void StudentButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Default2.aspx");
        }
    }
}