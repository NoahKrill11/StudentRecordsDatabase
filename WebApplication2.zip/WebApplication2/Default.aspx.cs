﻿using System;
using System.Web.UI;
using System.Text;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Web;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;



namespace WebApplication2
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void printStudents(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                int ID = Convert.ToInt32(TxtSearch.Text);
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT FirstName, LastName, Student.PersonID, Student.StudentID ");
                sb.Append("FROM Person INNER JOIN Student ON Student.PersonID = Person.PersonID WHERE Student.StudentID = " + ID);
                String sql = sb.ToString();
                SqlCommand cmd = new SqlCommand(sql, connection);
                connection.Open();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                connection.Close();
            }
        }
        protected void addCourse(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";
            int TeacherID;
            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                int StudentID = Convert.ToInt32(addStudentID.Text);
                int CourseID = Convert.ToInt32(addCourseID.Text);
                // Random random = new Random();
                //int recordNumber= random.Next(100000);
                String sb2 = ("Select TeacherID FROM teaches WHERE CourseNumber = @CourseID");

                string sb = ("INSERT into Courses2 (StudentID, CourseNumber, TeacherID) VALUES (@StudentID, @CourseID, @TeacherID)");
                connection.Open();
                using (SqlCommand command = new SqlCommand(sb2, connection))
                {
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    TeacherID = (int)command.ExecuteScalar();
                }
                using (SqlCommand command = new SqlCommand(sb, connection))
                {
                    command.Parameters.AddWithValue("@TeacherID", TeacherID);
                    command.Parameters.AddWithValue("@StudentID", StudentID);
                    command.Parameters.AddWithValue("@CourseID", CourseID);
                    command.ExecuteNonQuery();

                }
                connection.Close();

            }

           }
        protected void deleteCourse(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            Console.WriteLine("Enter the username to database");
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                int StudentID = Convert.ToInt32(TxtBoxIDD.Text);
                int CourseID = Convert.ToInt32(TxtBoxCID.Text);
                String message = "Record deleted successfully!";
                String refresh = "window.onload=function(){ alert('";
                String sb = ("DELETE FROM IDandClassID WHERE StudentID = " + StudentID + " AND CourseID = " + CourseID);
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(sb, connection))
                {
                    cmd.ExecuteNonQuery();
                }
                refresh += message;
                refresh += "');";
                refresh += "window.location='";
                refresh += Request.Url.AbsoluteUri;
                refresh += "';}";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", refresh, true);
                connection.Close();
            }
        }

        protected void addStudent(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                String sb, sb2,sb3;
                String message = "Student added successfully!";
                String refresh = "window.onload=function(){ alert('";
               // int StudentID = Convert.ToInt32(TxtBoxID.Text);
                String FirstName = TxtBoxFN.Text;
                String LastName = TxtBoxLN.Text;
                String Email = TxtBoxEM.Text;
                String DOB = TxtBoxDOB.Text;
                //Random random = new Random();
                // int personID = random.Next(100000);
                int personID;

                sb = ("INSERT into person (FirstName,LastName,DateOfBirth) VALUES (@FirstName,@LastName, @DateOfBirth)");
                sb2 = ("INSERT into Student (PersonID,Email) VALUES (@PersonID,@Email)");
                sb3 = ("SELECT PersonID FROM Person WHERE FirstName =  @FirstName AND LastName = @LastName");
                connection.Open();
                
                using (SqlCommand command = new SqlCommand(sb, connection))
                {
                   //command.Parameters.AddWithValue("@personID", personID);
                    command.Parameters.AddWithValue("@FirstName", FirstName);
                    command.Parameters.AddWithValue("@LastName", LastName);
                    command.Parameters.AddWithValue("@dateOfBirth", DOB);

                    command.ExecuteNonQuery();
                }
                using (SqlCommand command2 = new SqlCommand(sb3, connection))
                {
                    command2.Parameters.AddWithValue("@FirstName", FirstName);
                    command2.Parameters.AddWithValue("@LastName", LastName);
                    personID = (int)command2.ExecuteScalar();
                }
                using (SqlCommand command = new SqlCommand(sb2, connection))
                {
                    //command.Parameters.AddWithValue("@StudentID", StudentID);
                    command.Parameters.AddWithValue("@personID", personID);
                    command.Parameters.AddWithValue("@Email", Email);
                    command.ExecuteNonQuery();
                }
 
                refresh += message;
                refresh += "');";
                refresh += "window.location='";
                refresh += Request.Url.AbsoluteUri;
                refresh += "';}";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", refresh, true);
                connection.Close();
            }
        }


        protected void ViewClasses(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                String courseName = TxtCName.Text;
                int StudentID = Convert.ToInt32(stud.Text);
                while (StudentID < 0 || StudentID > 99999999)
                {
                    StudentID = Convert.ToInt32(Console.ReadLine());
                }
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT CourseID, Courses.NameofCourse, Courses.TeacherName FROM IDandClassID INNER JOIN Courses ON Courses.CourseNumber = IDandClassID.CourseID WHERE IDandClassID.StudentID = " + StudentID);
                String sql = sb.ToString();
                SqlCommand command = new SqlCommand(sql, connection);
                connection.Open();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(command);
                sda.Fill(dt);
                GridView1.DataSource = dt;
                GridView1.DataBind();
                connection.Close();
              
            }
        }

        public void addClass(object sender, EventArgs e)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = "studentrecordsua.database.windows.net";
            builder.UserID = "noahkrill11";
            builder.Password = "Uakron2019";
            builder.InitialCatalog = "StudentData";

            using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
            {
                String sb;
                String NameOfCourse = TxtCName.Text;
                String TeacherName = TxtBoxInstructor.Text;
                String message = "Student added successfully!";
                String refresh = "window.onload=function(){ alert('";
                int courseNumber = Convert.ToInt32(TxtCNumber.Text);
                sb = "INSERT into Courses (courseNumber,NameOfCourse ,TeacherName) VALUES (@courseNumber,@NameOfCourse,@TeacherName)";
                using (SqlCommand command = new SqlCommand(sb, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@courseNumber", courseNumber);
                    command.Parameters.AddWithValue("@NameOfCourse", NameOfCourse);
                    command.Parameters.AddWithValue("@TeacherName", TeacherName);
                    command.ExecuteNonQuery();
                }
                refresh += message;
                refresh += "');";
                refresh += "window.location='";
                refresh += Request.Url.AbsoluteUri;
                refresh += "';}";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", refresh, true);
                connection.Close();
            }
        }  
    }
}

       